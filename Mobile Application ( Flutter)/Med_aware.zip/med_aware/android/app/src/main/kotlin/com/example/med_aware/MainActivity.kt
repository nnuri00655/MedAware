package com.example.med_aware

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
