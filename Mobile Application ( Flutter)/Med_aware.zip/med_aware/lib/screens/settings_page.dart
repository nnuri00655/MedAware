import 'package:flutter/material.dart';
import 'change_password_page.dart';
import 'change_language_page.dart';

class SettingsPage extends StatefulWidget {
  @override
  _SettingsPageState createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  bool isDarkMode = false; // Track theme mode
  bool isNotificationEnabled = true; // Track notifications
  String currentLanguage = "English"; // Default language

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFF52796F)),
          onPressed: () {
            Navigator.pop(context); // Go back to the previous screen
          },
        ),
        title: const Text(
          'Settings',
          style: TextStyle(
            color: Color(0xFF52796F),
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          // Theme Toggle Section
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                "Theme",
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Switch(
                value: isDarkMode,
                onChanged: (bool value) {
                  setState(() {
                    isDarkMode = value;
                    // Apply theme toggle logic if necessary
                  });
                },
              ),
            ],
          ),
          const Divider(),

          // Notification Toggle Section
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                "Notification",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              Switch(
                value: isNotificationEnabled,
                onChanged: (bool value) {
                  setState(() {
                    isNotificationEnabled = value;
                  });
                },
              ),
            ],
          ),
          const Divider(),

          // Language Setting
          ListTile(
            title: const Text("Language"),
            subtitle: Text(currentLanguage), // Show the selected language
            trailing: const Icon(Icons.arrow_forward_ios),
            onTap: () {
              // Navigate to ChangeLanguagePage
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ChangeLanguagePage(
                    currentLanguage: currentLanguage,
                    onLanguageChange: (newLanguage) {
                      setState(() {
                        currentLanguage = newLanguage; // Update language
                      });
                    },
                  ),
                ),
              );
            },
          ),
          const Divider(),

          // Security Setting
          ListTile(
            title: const Text("Password Change"),
            subtitle: const Text("Manage security"),
            trailing: ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ChangePasswordPage(),
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFE0F2F1), // Lighter button color
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
              child: const Text(
                "Manage",
                style: TextStyle(
                  color: Color(0xFF52796F),
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          const Divider(),

          // Help & Support
          const ListTile(
            title: Text("Help & Support"),
          ),
          ListTile(
            title: const Text("About us"),
            trailing: const Icon(Icons.arrow_forward_ios),
            onTap: () {
              // Navigate to about us page
            },
          ),
          ListTile(
            title: const Text("Terms & Conditions"),
            trailing: const Icon(Icons.arrow_forward_ios),
            onTap: () {
              // Navigate to terms and conditions page
            },
          ),
          ListTile(
            title: const Text("Privacy Policy"),
            trailing: const Icon(Icons.arrow_forward_ios),
            onTap: () {
              // Navigate to privacy policy page
            },
          ),
        ],
      ),
    );
  }
}


