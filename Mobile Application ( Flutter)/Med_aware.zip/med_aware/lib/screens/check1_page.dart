import 'package:flutter/material.dart';

class Check1Page extends StatefulWidget {
  @override
  _Check1PageState createState() => _Check1PageState();
}

class _Check1PageState extends State<Check1Page> {
  final Map<String, dynamic> _answers = {
    "fever": null,
    "temperature": "",
    "chestPain": null,
    "difficultyBreathing": null,
    "breathingWorse": "",
    "coughing": null,
    "coughType": "",
  };

  void _updateAnswer(String key, dynamic value) {
    setState(() {
      _answers[key] = value;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: const Color(0xFF52796F),
        child: SafeArea(
          child: Container(
            padding: const EdgeInsets.all(16.0),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(30),
                topRight: Radius.circular(30),
              ),
            ),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    decoration: BoxDecoration(
                      color: const Color(0xFFE8F5E9),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Center(
                      child: Text(
                        "General Health Questions",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF52796F),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  _buildQuestionContainer(
                    QuestionWidget(
                      question: "1. Do you currently have a fever?",
                      options: ["Yes", "No"],
                      selectedOption: _answers["fever"],
                      onOptionSelected: (value) => _updateAnswer("fever", value),
                      additionalFieldHint: "Please enter your temperature: ___°C",
                      additionalFieldKey: "temperature",
                      additionalFieldValue: _answers["temperature"],
                      onAdditionalFieldChanged: (value) => _updateAnswer("temperature", value),
                    ),
                  ),
                  _buildQuestionContainer(
                    QuestionWidget(
                      question: "2. Are you experiencing any chest pain?",
                      options: ["Yes", "No"],
                      selectedOption: _answers["chestPain"],
                      onOptionSelected: (value) => _updateAnswer("chestPain", value),
                    ),
                  ),
                  _buildQuestionContainer(
                    QuestionWidget(
                      question: "3. Do you have difficulty breathing?",
                      options: ["Yes", "No"],
                      selectedOption: _answers["difficultyBreathing"],
                      onOptionSelected: (value) => _updateAnswer("difficultyBreathing", value),
                      additionalFieldHint: "Is it worse when lying down or sitting up?",
                      additionalFieldKey: "breathingWorse",
                      additionalFieldValue: _answers["breathingWorse"],
                      onAdditionalFieldChanged: (value) => _updateAnswer("breathingWorse", value),
                    ),
                  ),
                  _buildQuestionContainer(
                    QuestionWidget(
                      question: "4. Have you been coughing?",
                      options: ["Yes", "No"],
                      selectedOption: _answers["coughing"],
                      onOptionSelected: (value) => _updateAnswer("coughing", value),
                      additionalFieldHint: "Is it a dry cough or with phlegm?",
                      additionalFieldKey: "coughType",
                      additionalFieldValue: _answers["coughType"],
                      onAdditionalFieldChanged: (value) => _updateAnswer("coughType", value),
                    ),
                  ),
                  const SizedBox(height: 40),
                  Center(
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.pushNamed(context, '/check2');
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFE8F5E9),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 100,
                          vertical: 15,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30),
                        ),
                      ),
                      child: const Text(
                        "NEXT",
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF52796F),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: "Home",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.pie_chart),
            label: "Analytics",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.favorite),
            label: "Favorites",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: "Settings",
          ),
        ],
        selectedItemColor: Color(0xFF52796F),
        unselectedItemColor: Colors.grey,
        onTap: (index) {
          // Handle navigation based on index
        },
      ),
    );
  }

  Widget _buildQuestionContainer(Widget child) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: child,
    );
  }
}

class QuestionWidget extends StatelessWidget {
  final String question;
  final List<String> options;
  final String? selectedOption;
  final Function(String) onOptionSelected;
  final String? additionalFieldHint;
  final String? additionalFieldKey;
  final String? additionalFieldValue;
  final Function(String)? onAdditionalFieldChanged;

  const QuestionWidget({
    Key? key,
    required this.question,
    required this.options,
    required this.onOptionSelected,
    this.selectedOption,
    this.additionalFieldHint,
    this.additionalFieldKey,
    this.additionalFieldValue,
    this.onAdditionalFieldChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          question,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
        const SizedBox(height: 10),
        ...options.map(
              (option) => GestureDetector(
            onTap: () => onOptionSelected(option),
            child: Row(
              children: [
                Radio(
                  value: option,
                  groupValue: selectedOption,
                  onChanged: (value) => onOptionSelected(value as String),
                ),
                Text(option),
              ],
            ),
          ),
        ),
        if (additionalFieldHint != null && onAdditionalFieldChanged != null)
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: TextField(
              decoration: InputDecoration(
                hintText: additionalFieldHint,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              onChanged: (value) => onAdditionalFieldChanged!(value),
            ),
          ),
      ],
    );
  }
}