import 'package:flutter/material.dart';

class Check2Page extends StatefulWidget {
  @override
  _Check2PageState createState() => _Check2PageState();
}

class _Check2PageState extends State<Check2Page> {
  final Map<String, dynamic> _answers = {
    "shortnessOfBreath": null,
    "wheezing": null,
    "nasalCongestion": null,
    "soreThroat": null,
  };

  void _updateAnswer(String key, dynamic value) {
    setState(() {
      _answers[key] = value;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: const Color(0xFF52796F),
        child: SafeArea(
          child: Container(
            padding: const EdgeInsets.all(16.0),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(30),
                topRight: Radius.circular(30),
              ),
            ),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    decoration: BoxDecoration(
                      color: const Color(0xFFE8F5E9),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Center(
                      child: Text(
                        "Respiratory Symptoms",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF52796F),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  _buildQuestionContainer(
                    QuestionWidget(
                      question: "1. Do you feel shortness of breath after physical activity?",
                      options: ["Yes", "No"],
                      selectedOption: _answers["shortnessOfBreath"],
                      onOptionSelected: (value) => _updateAnswer("shortnessOfBreath", value),
                    ),
                  ),
                  _buildQuestionContainer(
                    QuestionWidget(
                      question: "2. Have you experienced wheezing (whistling sound while breathing)?",
                      options: ["Yes", "No"],
                      selectedOption: _answers["wheezing"],
                      onOptionSelected: (value) => _updateAnswer("wheezing", value),
                    ),
                  ),
                  _buildQuestionContainer(
                    QuestionWidget(
                      question: "3. Are you experiencing nasal congestion or a runny nose?",
                      options: ["Yes", "No"],
                      selectedOption: _answers["nasalCongestion"],
                      onOptionSelected: (value) => _updateAnswer("nasalCongestion", value),
                    ),
                  ),
                  _buildQuestionContainer(
                    QuestionWidget(
                      question: "4. Are you experiencing a sore throat?",
                      options: ["Yes", "No"],
                      selectedOption: _answers["soreThroat"],
                      onOptionSelected: (value) => _updateAnswer("soreThroat", value),
                    ),
                  ),
                  const SizedBox(height: 40),
                  Center(
                    child: ElevatedButton(
                      onPressed: () {
                        print(_answers); // Log or save answers
                        Navigator.pushNamed(context, '/check3'); // Navigate to Check3Page
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFE8F5E9),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 100,
                          vertical: 15,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30),
                        ),
                      ),
                      child: const Text(
                        "NEXT",
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF52796F),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: "Home",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.pie_chart),
            label: "Analytics",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.favorite),
            label: "Favorites",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: "Settings",
          ),
        ],
        selectedItemColor: Color(0xFF52796F),
        unselectedItemColor: Colors.grey,
        onTap: (index) {
          // Handle navigation based on index
        },
      ),
    );
  }

  Widget _buildQuestionContainer(Widget child) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: child,
    );
  }
}

class QuestionWidget extends StatelessWidget {
  final String question;
  final List<String> options;
  final String? selectedOption;
  final Function(String) onOptionSelected;

  const QuestionWidget({
    Key? key,
    required this.question,
    required this.options,
    required this.onOptionSelected,
    this.selectedOption,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          question,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
        const SizedBox(height: 10),
        ...options.map(
              (option) => GestureDetector(
            onTap: () => onOptionSelected(option),
            child: Row(
              children: [
                Radio(
                  value: option,
                  groupValue: selectedOption,
                  onChanged: (value) => onOptionSelected(value as String),
                ),
                Text(option),
              ],
            ),
          ),
        ),
      ],
    );
  }
}