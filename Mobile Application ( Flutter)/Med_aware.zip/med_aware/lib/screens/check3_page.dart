import 'package:flutter/material.dart';

class Check3Page extends StatefulWidget {
  @override
  _Check3PageState createState() => _Check3PageState();
}

class _Check3PageState extends State<Check3Page> {
  final Map<String, dynamic> _answers = {
    "highBloodPressure": null,
    "bloodPressure": "",
    "heartPalpitations": null,
    "musclePain": null,
    "fatigue": null,
    "nausea": null,
  };

  void _updateAnswer(String key, dynamic value) {
    setState(() {
      _answers[key] = value;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: const Color(0xFF52796F),
        child: SafeArea(
          child: Container(
            padding: const EdgeInsets.all(16.0),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(30),
                topRight: Radius.circular(30),
              ),
            ),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    decoration: BoxDecoration(
                      color: const Color(0xFFE8F5E9),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Center(
                      child: Text(
                        "Cardiovascular and Blood Pressure",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF52796F),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  _buildQuestionContainer(
                    QuestionWidget(
                      question: "1. Do you have high blood pressure?",
                      options: ["Yes", "No"],
                      selectedOption: _answers["highBloodPressure"],
                      onOptionSelected: (value) => _updateAnswer("highBloodPressure", value),
                      additionalFieldHint: "Please enter your blood pressure: ___ / ___ mmHg",
                      additionalFieldKey: "bloodPressure",
                      additionalFieldValue: _answers["bloodPressure"],
                      onAdditionalFieldChanged: (value) => _updateAnswer("bloodPressure", value),
                    ),
                  ),
                  _buildQuestionContainer(
                    QuestionWidget(
                      question: "2. Have you experienced heart palpitations recently?",
                      options: ["Yes", "No"],
                      selectedOption: _answers["heartPalpitations"],
                      onOptionSelected: (value) => _updateAnswer("heartPalpitations", value),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Container(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    decoration: BoxDecoration(
                      color: const Color(0xFFE8F5E9),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Center(
                      child: Text(
                        "Other Symptoms",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF52796F),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  _buildQuestionContainer(
                    QuestionWidget(
                      question: "1. Are you experiencing muscle pain or body aches?",
                      options: ["Yes", "No"],
                      selectedOption: _answers["musclePain"],
                      onOptionSelected: (value) => _updateAnswer("musclePain", value),
                    ),
                  ),
                  _buildQuestionContainer(
                    QuestionWidget(
                      question: "2. Are you feeling fatigue or general weakness?",
                      options: ["Yes", "No"],
                      selectedOption: _answers["fatigue"],
                      onOptionSelected: (value) => _updateAnswer("fatigue", value),
                    ),
                  ),
                  _buildQuestionContainer(
                    QuestionWidget(
                      question: "3. Have you experienced nausea or vomiting?",
                      options: ["Yes", "No"],
                      selectedOption: _answers["nausea"],
                      onOptionSelected: (value) => _updateAnswer("nausea", value),
                    ),
                  ),
                  const SizedBox(height: 40),
                  Center(
                    child: ElevatedButton(
                      onPressed: () {
                        print(_answers); // Save or use the answers
                        Navigator.pushNamed(context, '/check-finish');
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFE8F5E9),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 100,
                          vertical: 15,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30),
                        ),
                      ),
                      child: const Text(
                        "ANALYZE SYMPTOMS",
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF52796F),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: "Home",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.pie_chart),
            label: "Analytics",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.favorite),
            label: "Favorites",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: "Settings",
          ),
        ],
        selectedItemColor: Color(0xFF52796F),
        unselectedItemColor: Colors.grey,
        onTap: (index) {
          // Handle navigation based on index
        },
      ),
    );
  }

  Widget _buildQuestionContainer(Widget child) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: child,
    );
  }
}

class QuestionWidget extends StatelessWidget {
  final String question;
  final List<String> options;
  final String? selectedOption;
  final Function(String) onOptionSelected;
  final String? additionalFieldHint;
  final String? additionalFieldKey;
  final String? additionalFieldValue;
  final Function(String)? onAdditionalFieldChanged;

  const QuestionWidget({
    Key? key,
    required this.question,
    required this.options,
    required this.onOptionSelected,
    this.selectedOption,
    this.additionalFieldHint,
    this.additionalFieldKey,
    this.additionalFieldValue,
    this.onAdditionalFieldChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          question,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
        const SizedBox(height: 10),
        ...options.map(
              (option) => GestureDetector(
            onTap: () => onOptionSelected(option),
            child: Row(
              children: [
                Radio(
                  value: option,
                  groupValue: selectedOption,
                  onChanged: (value) => onOptionSelected(value as String),
                ),
                Text(option),
              ],
            ),
          ),
        ),
        if (additionalFieldHint != null && onAdditionalFieldChanged != null)
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: TextField(
              decoration: InputDecoration(
                hintText: additionalFieldHint,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              onChanged: (value) => onAdditionalFieldChanged!(value),
            ),
          ),
      ],
    );
  }
}