import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class CheckXRayPage extends StatefulWidget {
  @override
  _CheckXRayPageState createState() => _CheckXRayPageState();
}

class _CheckXRayPageState extends State<CheckXRayPage> {
  XFile? _selectedImage;

  Future<void> _pickImage() async {
    final ImagePicker _picker = ImagePicker();
    final XFile? pickedImage = await _picker.pickImage(source: ImageSource.gallery);
    setState(() {
      _selectedImage = pickedImage;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFF52796F)),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          "Check X-Ray",
          style: TextStyle(
            color: Color(0xFF52796F),
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _selectedImage == null
                  ? Image.asset(
                "assets/icons/xray_icon.png", // Update path if necessary
                height: 250, // Increased height
                width: 250, // Added width to maintain proportion
                fit: BoxFit.contain,
              )
                  : Image.file(
                File(_selectedImage!.path),
                height: 250, // Match size of the placeholder icon
                width: 250,
                fit: BoxFit.cover,
              ),
              const SizedBox(height: 20),
              TextButton.icon(
                onPressed: _pickImage,
                icon: const Icon(Icons.upload, color: Colors.white),
                label: const Text(
                  "Upload",
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                style: TextButton.styleFrom(
                  backgroundColor: const Color(0xFF52796F),
                  padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 16),
                child: Text(
                  "Upload your X-ray for a preliminary scan. Results are not guaranteed to be accurate; always consult a doctor for a thorough evaluation.",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.grey,
                    fontSize: 14,
                  ),
                ),
              ),
              const SizedBox(height: 40),
              ElevatedButton(
                onPressed: () {
                  // Add your scan functionality here
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF52796F),
                  padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: const Text(
                  "Scan",
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}


