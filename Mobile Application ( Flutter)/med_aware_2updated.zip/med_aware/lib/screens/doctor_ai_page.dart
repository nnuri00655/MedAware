import 'package:flutter/material.dart';

class DoctorAIPage extends StatefulWidget {
  @override
  _DoctorAIPageState createState() => _DoctorAIPageState();
}

class _DoctorAIPageState extends State<DoctorAIPage> {
  final List<Map<String, String>> _messages = [
    {"sender": "AI", "text": "Hello! How are you feeling? What are your symptoms?"},
  ];

  final TextEditingController _controller = TextEditingController();
  bool _waitingForResponse = false;

  void _sendMessage(String text) {
    setState(() {
      _messages.add({"sender": "User", "text": text});
      _controller.clear();
      _waitingForResponse = true;
    });

    Future.delayed(const Duration(seconds: 2), () {
      setState(() {
        _messages.add({
          "sender": "AI",
          "text": _generateAIResponse(text),
        });
        _waitingForResponse = false;
      });
    });
  }

  String _generateAIResponse(String input) {
    if (_messages.length == 2) {
      return "I understand. Let’s clarify the details. When exactly did the symptoms begin?";
    } else if (_messages.length == 4) {
      return "Have you already taken any medications?";
    } else if (_messages.length == 6) {
      return "Do you have any chronic diseases, such as asthma or heart problems?";
    } else if (_messages.length == 8) {
      return "Based on your symptoms, you might have a respiratory infection. Drink fluids, rest, and monitor breathing. If it gets worse, visit a doctor.";
    } else {
      return "Thank you for sharing. Take care!";
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        automaticallyImplyLeading: false,
        title: const Center(
          child: Text(
            "DoctorAI",
            style: TextStyle(
              color: Color(0xFF52796F),
              fontWeight: FontWeight.bold,
              fontSize: 24,
            ),
          ),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Chat Section
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.all(16.0),
                itemCount: _messages.length,
                itemBuilder: (context, index) {
                  final message = _messages[index];
                  final isAI = message["sender"] == "AI";
                  return Row(
                    mainAxisAlignment:
                    isAI ? MainAxisAlignment.start : MainAxisAlignment.end,
                    children: [
                      if (isAI) ...[
                        CircleAvatar(
                          backgroundColor: const Color(0xFF52796F),
                          child: const Icon(Icons.health_and_safety,
                              color: Colors.white),
                        ),
                        const SizedBox(width: 8),
                      ],
                      Flexible(
                        child: Container(
                          margin: const EdgeInsets.symmetric(vertical: 4),
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: isAI
                                ? const Color(0xFF52796F)
                                : Colors.grey.shade200,
                            borderRadius: BorderRadius.only(
                              topLeft: const Radius.circular(12),
                              topRight: const Radius.circular(12),
                              bottomLeft: isAI
                                  ? const Radius.circular(0)
                                  : const Radius.circular(12),
                              bottomRight: isAI
                                  ? const Radius.circular(12)
                                  : const Radius.circular(0),
                            ),
                          ),
                          child: Text(
                            message["text"]!,
                            style: TextStyle(
                              color:
                              isAI ? Colors.white : const Color(0xFF52796F),
                            ),
                          ),
                        ),
                      ),
                      if (!isAI) ...[
                        const SizedBox(width: 8),
                        CircleAvatar(
                          backgroundColor: Colors.grey.shade200,
                          child: const Icon(Icons.person,
                              color: Color(0xFF52796F)),
                        ),
                      ],
                    ],
                  );
                },
              ),
            ),

            // Input Section
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.grey.shade200,
                        borderRadius: BorderRadius.circular(30),
                      ),
                      child: TextField(
                        controller: _controller,
                        decoration: InputDecoration(
                          hintText: "Type your response...",
                          hintStyle: TextStyle(color: Colors.grey.shade600),
                          border: InputBorder.none,
                          contentPadding: const EdgeInsets.symmetric(
                            vertical: 10,
                            horizontal: 20,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  CircleAvatar(
                    radius: 24,
                    backgroundColor: _waitingForResponse
                        ? Colors.grey
                        : const Color(0xFF52796F),
                    child: IconButton(
                      icon: const Icon(Icons.send, color: Colors.white),
                      onPressed: _waitingForResponse
                          ? null
                          : () {
                        if (_controller.text.trim().isNotEmpty) {
                          _sendMessage(_controller.text.trim());
                        }
                      },
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),

      // Bottom Navigation Bar
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: 1,
        onTap: (index) {
          if (index == 0) {
            Navigator.pushNamed(context, '/home');
          } else if (index == 1) {
            // Stay on DoctorAI
          } else if (index == 2) {
            Navigator.pushNamed(context, '/chat-bot');
          } else if (index == 3) {
            Navigator.pushNamed(context, '/profile');
          }
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: "Home",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.health_and_safety),
            label: "AI Doctors",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.chat),
            label: "Chat",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: "Profile",
          ),
        ],
        selectedItemColor: const Color(0xFF52796F),
        unselectedItemColor: Colors.grey,
      ),
    );
  }
}
