import 'dart:async';
import 'package:flutter/material.dart';

class CheckFinishPage extends StatefulWidget {
  @override
  _CheckFinishPageState createState() => _CheckFinishPageState();
}

class _CheckFinishPageState extends State<CheckFinishPage> {
  double progress = 0;

  @override
  void initState() {
    super.initState();
    _startProgress();
  }

  void _startProgress() {
    Timer.periodic(const Duration(milliseconds: 100), (timer) {
      if (progress >= 100) {
        timer.cancel();
      } else {
        setState(() {
          progress += (progress == 56 ? 3 : 5); // Pause increment at 56% briefly
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: const Color(0xFF52796F),
        child: SafeArea(
          child: Container(
            padding: const EdgeInsets.all(16.0),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(30),
                topRight: Radius.circular(30),
              ),
            ),
            child: progress < 100
                ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      SizedBox(
                        width: 250,
                        height: 250,
                        child: CircularProgressIndicator(
                          value: progress / 100,
                          backgroundColor: Colors.grey.shade300,
                          valueColor: AlwaysStoppedAnimation<Color>(
                            const Color(0xFF52796F),
                          ),
                          strokeWidth: 12.0,
                        ),
                      ),
                      Text(
                        "${progress.toInt()}%",
                        style: const TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF52796F),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            )
                : SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Center(
                    child: Text(
                      "Preliminary Symptom Analysis",
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF52796F),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  _buildResultCard(
                    title: "Upper Respiratory Infection",
                    percentage: "80%",
                    description:
                    "Fever, coughing with phlegm, mild muscle pain.",
                    color: Colors.red,
                  ),
                  _buildResultCard(
                    title: "Bronchitis",
                    percentage: "35%",
                    description:
                    "Persistent cough with phlegm, chest pain, shortness of breath after physical activity.",
                    color: Colors.orange,
                  ),
                  _buildResultCard(
                    title: "Mild Pneumonia",
                    percentage: "15%",
                    description:
                    "Fever, shortness of breath, chest pain, dry cough.",
                    color: Colors.purple,
                  ),
                  _buildResultCard(
                    title:
                    "Other Possible Conditions (e.g., Asthma, Allergies)",
                    percentage: "5%",
                    description: "",
                    color: Colors.teal,
                  ),
                  const SizedBox(height: 20),
                  const Divider(thickness: 1, color: Colors.grey),
                  const SizedBox(height: 10),
                  const Text(
                    "Confidence: 98%",
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF52796F),
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 20),
                  Center(
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.pushNamed(context, '/home');
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF52796F),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 100,
                          vertical: 15,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30),
                        ),
                      ),
                      child: const Text(
                        "DONE",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildResultCard({
    required String title,
    required String percentage,
    required String description,
    required Color color,
  }) {
    return Card(
      elevation: 4,
      margin: const EdgeInsets.symmetric(vertical: 10),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          children: [
            CircleAvatar(
              radius: 25,
              backgroundColor: color.withOpacity(0.2),
              child: Text(
                percentage,
                style: TextStyle(
                  color: color,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    description,
                    style: const TextStyle(
                      fontSize: 14,
                      color: Colors.black54,
                    ),
                  ),
                ],
              ),
            ),
            const Icon(Icons.arrow_forward, color: Color(0xFF52796F)),
          ],
        ),
      ),
    );
  }
}
