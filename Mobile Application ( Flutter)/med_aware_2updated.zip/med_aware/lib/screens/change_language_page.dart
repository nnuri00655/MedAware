import 'package:flutter/material.dart';

class ChangeLanguagePage extends StatefulWidget {
  final String currentLanguage;
  final Function(String) onLanguageChange;

  const ChangeLanguagePage({
    required this.currentLanguage,
    required this.onLanguageChange,
    Key? key,
  }) : super(key: key);

  @override
  _ChangeLanguagePageState createState() => _ChangeLanguagePageState();
}

class _ChangeLanguagePageState extends State<ChangeLanguagePage> {
  String? selectedLanguage;

  @override
  void initState() {
    super.initState();
    selectedLanguage = widget.currentLanguage;
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFF52796F)),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: const Text(
          'Language',
          style: TextStyle(
            color: Color(0xFF52796F),
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: Column(
        children: [
          SizedBox(height: screenHeight * 0.2), // Adjust the top padding
          Column(
            children: [
              _buildLanguageOption(
                "English",
                "assets/icons/uk.png",
              ),
              const SizedBox(height: 16),
              _buildLanguageOption(
                "Қазақша",
                "assets/icons/kz.png",
              ),
              const SizedBox(height: 16),
              _buildLanguageOption(
                "Русский",
                "assets/icons/ru.png",
              ),
            ],
          ),
          const SizedBox(height: 32), // Gap between languages and the button
          ElevatedButton(
            onPressed: () {
              widget.onLanguageChange(selectedLanguage!);
              Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF52796F),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(25),
              ),
              padding: const EdgeInsets.symmetric(
                vertical: 16,
                horizontal: 64,
              ),
              elevation: 5,
            ),
            child: const Text(
              "DONE",
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(height: 24), // Adjusted bottom margin for better spacing
        ],
      ),
    );
  }

  Widget _buildLanguageOption(String language, String iconPath) {
    return GestureDetector(
      onTap: () {
        setState(() {
          selectedLanguage = language;
        });
      },
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: selectedLanguage == language
              ? const Color(0xFF52796F).withOpacity(0.2)
              : Colors.grey.shade100,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.shade300,
              blurRadius: 6,
              spreadRadius: 2,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Row(
          children: [
            Image.asset(iconPath, width: 32, height: 32),
            const SizedBox(width: 16),
            Text(
              language,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
                color: selectedLanguage == language
                    ? const Color(0xFF52796F)
                    : Colors.black,
              ),
            ),
          ],
        ),
      ),
    );
  }
}






