import 'package:flutter/material.dart';

class LanguagePage extends StatefulWidget {
  @override
  _LanguagePageState createState() => _LanguagePageState();
}

class _LanguagePageState extends State<LanguagePage> {
  String? selectedLanguage;

  void selectLanguage(String language) {
    setState(() {
      selectedLanguage = language;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true, // Avoid keyboard overflow
      body: Column(
        children: [
          // Header Section (27% of screen height)
          Container(
            width: double.infinity,
            height: MediaQuery.of(context).size.height * 0.27,
            color: const Color(0xFF52796F), // Green background
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset(
                    'assets/icons/medical.png',
                    height: 100, // Adjusted size for better proportions
                    width: 100,
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    'CHOOSE THE LANGUAGE',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Language Selection Section (73% of screen height)
          Expanded(
            child: Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.white, // Ensure the background is white
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(30),
                  topRight: Radius.circular(30),
                ),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    GestureDetector(
                      onTap: () => selectLanguage('English'),
                      child: LanguageOption(
                        flagPath: 'assets/icons/uk.png',
                        language: 'English',
                        isSelected: selectedLanguage == 'English',
                      ),
                    ),
                    GestureDetector(
                      onTap: () => selectLanguage('Kazakh'),
                      child: LanguageOption(
                        flagPath: 'assets/icons/kz.png',
                        language: 'Қазақша',
                        isSelected: selectedLanguage == 'Kazakh',
                      ),
                    ),
                    GestureDetector(
                      onTap: () => selectLanguage('Russian'),
                      child: LanguageOption(
                        flagPath: 'assets/icons/ru.png',
                        language: 'Русский',
                        isSelected: selectedLanguage == 'Russian',
                      ),
                    ),
                    const SizedBox(height: 30),
                    ElevatedButton(
                      onPressed: selectedLanguage != null
                          ? () {
                        Navigator.pushNamed(context, '/signin');
                      }
                          : null,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: selectedLanguage != null
                            ? const Color(0xFF52796F)
                            : const Color(0xFF52796F).withOpacity(0.5),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 50, vertical: 15),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30),
                        ),
                      ),
                      child: const Text(
                        'CONTINUE',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    const SizedBox(height: 20), // Padding to ensure proper spacing
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// Language Option Widget
class LanguageOption extends StatelessWidget {
  final String flagPath;
  final String language;
  final bool isSelected;

  const LanguageOption({
    required this.flagPath,
    required this.language,
    required this.isSelected,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(
        color: isSelected ? Colors.grey[200] : Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isSelected ? const Color(0xFF52796F) : Colors.grey[300]!,
          width: 2,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 2,
            blurRadius: 5,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: ListTile(
        leading: Image.asset(
          flagPath,
          width: 40,
          height: 40,
        ),
        title: Text(
          language,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }
}
