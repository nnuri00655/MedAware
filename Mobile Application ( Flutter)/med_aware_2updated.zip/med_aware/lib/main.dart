import 'package:flutter/material.dart';
import 'screens/language_page.dart';
import 'screens/signin_page.dart';
import 'screens/signin_success_page.dart';
import 'screens/forgot_password_page.dart';
import 'screens/reset_password_page.dart';
import 'screens/verify_code_page.dart';
import 'screens/password_success_page.dart';
import 'screens/signup_page.dart';
import 'screens/signup_success_page.dart';
import 'screens/signup_option_page.dart';
import 'screens/home_page.dart';
import 'screens/check_symptoms_page.dart';
import 'screens/check1_page.dart' as check1; // Alias for check1_page
import 'screens/check2_page.dart' as check2; // Alias for check2_page
import 'screens/check3_page.dart';
import 'screens/check_finish_page.dart';
import 'screens/check_xray_page.dart';
import 'screens/settings_page.dart'; // New import for SettingsPage
import 'screens/profile_page.dart';
import 'screens/doctor_ai_page.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MedAware',
      theme: ThemeData(
        primarySwatch: Colors.teal,
        scaffoldBackgroundColor: Colors.white,
      ),
      initialRoute: '/language',
      routes: {
        '/language': (context) => LanguagePage(),
        '/signin': (context) => SignInPage(),
        '/signup': (context) => SignUpPage(),
        '/signup-success': (context) => SignUpSuccessPage(),
        '/signup-option': (context) => SignUpOptionPage(
          username: 'Zhamilya Abdildanova',
          email: '31268@iitu.edu.kz',
        ),
        '/signin-success': (context) => SignInSuccessPage(),
        '/forgot-password': (context) => ForgotPasswordPage(),
        '/verify-code': (context) => VerifyCodePage(email: ''),
        '/reset-password': (context) => ResetPasswordPage(),
        '/password-success': (context) => PasswordSuccessPage(),
        '/home': (context) => HomePage(),
        '/check-symptoms': (context) => CheckSymptomsPage(),
        '/check1': (context) => check1.Check1Page(),
        '/check2': (context) => check2.Check2Page(),
        '/check3': (context) => Check3Page(),
        '/check-finish': (context) => CheckFinishPage(),
        '/settings': (context) => SettingsPage(), // New route for settings
        '/profile': (context) => ProfilePage(),
        '/doctor_ai': (context) => DoctorAIPage(),
        '/check-xray': (context) => CheckXRayPage(), // New route for profile
      },
    );
  }
}

