package iitu.edu.kz.medaware.controller;

import iitu.edu.kz.medaware.model.*;
import iitu.edu.kz.medaware.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/treatment-plans")
public class Treatment_planController {

    @Autowired
    private Treatment_planService treatmentPlanService;

    @GetMapping
    public List<Treatment_plan> getAllTreatmentPlans() {
        return treatmentPlanService.getAllTreatmentPlans();
    }

    @GetMapping("/user/{userId}")
    public List<Treatment_plan> getTreatmentPlansByUser(@PathVariable Integer userId) {
        return treatmentPlanService.getTreatmentPlansByUserId(userId);
    }

    @PostMapping
    public Treatment_plan saveTreatmentPlan(@RequestBody Treatment_plan treatmentPlan) {
        return treatmentPlanService.saveTreatmentPlan(treatmentPlan);
    }
}
