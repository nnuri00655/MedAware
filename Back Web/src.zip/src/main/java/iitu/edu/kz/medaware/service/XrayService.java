package iitu.edu.kz.medaware.service;

import iitu.edu.kz.medaware.model.*;
import iitu.edu.kz.medaware.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class XrayService {
    @Autowired
    private XrayRepository xrayImageRepository;

    public List<Xray> getAllXrayImages() {
        return xrayImageRepository.findAll();
    }

    public Xray saveXrayImage(Xray xrayImage) {
        return xrayImageRepository.save(xrayImage);
    }
}
