package iitu.edu.kz.medaware.controller;

import iitu.edu.kz.medaware.model.*;
import iitu.edu.kz.medaware.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/xray-images")
public class XrayController {

    @Autowired
    private XrayService xrayImageService;

    @GetMapping
    public List<Xray> getAllXrayImages() {
        return xrayImageService.getAllXrayImages();
    }

    @PostMapping
    public Xray saveXrayImage(@RequestBody Xray xrayImage) {
        return xrayImageService.saveXrayImage(xrayImage);
    }
}
