package iitu.edu.kz.medaware.model;

import jakarta.persistence.*;
import java.util.Date;
import java.util.List;
@Entity
@Table(name = "medical_history")
public class Medical_history {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(name = "diagnosis", nullable = false)
    private String diagnosis;

    @Column(name = "probability")
    private Double probability;

    @Column(name = "generated_from")
    private String generatedFrom;

    @Column(name = "created_at")
    private Date createdAt;

    @Column(name = "notes")
    private String notes;
}
