package iitu.edu.kz.medaware.controller;

import iitu.edu.kz.medaware.model.*;
import iitu.edu.kz.medaware.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/surveys")
public class SurveyController {

    @Autowired
    private SurveyService surveyService;

    @GetMapping
    public List<Survey> getAllSurveys() {
        return surveyService.getAllSurveys();
    }

    @PostMapping
    public Survey saveSurvey(@RequestBody Survey survey) {
        return surveyService.saveSurvey(survey);
    }
}

