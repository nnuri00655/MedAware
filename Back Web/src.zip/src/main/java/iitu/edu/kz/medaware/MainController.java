package iitu.edu.kz.medaware;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {

    @GetMapping("/index")
    public String showHomePage() {
        return "index";
    }

    @GetMapping("/diagnostics")
    public String showDiagnosticsPage() {
        return "diagnostics";
    }

    @GetMapping("/news")
    public String showNewsPage() {
        return "news";
    }

    @GetMapping("/team")
    public String showTeamPage() {
        return "team";
    }

    @GetMapping("/recommendations")
    public String showRecommendationsPage() {
        return "recommendations";
    }

    @GetMapping("/index-dark")
    public String showIndexPage() {
        return "index-dark";
    }

    @GetMapping("/signup")
    public String showSignupPage() {
        return "signup";
    }

    @GetMapping("/signin")
    public String showSigninPage() {
        return "signin";
    }

    @GetMapping("/faq")
    public String showFaqPage() {
        return "faq";
    }

    @GetMapping("/recommendationsmore")
    public String showRecommendationsMorePage() {
        return "recommendationsmore";
    }

    @GetMapping("/terms")
    public String showTermsPage() {
        return "terms";
    }

    @GetMapping("/profile")
    public String showProfilePage() {
        return "profile";
    }

    @GetMapping("/privacy")
    public String showPrivacyPage() {
        return "privacy";
    }

    @GetMapping("/forgotpassword")
    public String showForgotPasswordPage() {
        return "forgotpassword";
    }

    @GetMapping("/contact")
    public String showContactPage() {
        return "contact";
    }
}