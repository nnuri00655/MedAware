package iitu.edu.kz.medaware.controller;

import iitu.edu.kz.medaware.model.*;
import iitu.edu.kz.medaware.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/medical-histories")
public class Medical_historyController {

    @Autowired
    private MedicalHistoryService medicalHistoryService;

    @GetMapping
    public List<Medical_history> getAllMedicalHistories() {
        return medicalHistoryService.getAllMedicalHistories();
    }

    @PostMapping
    public Medical_history saveMedicalHistory(@RequestBody Medical_history medicalHistory) {
        return medicalHistoryService.saveMedicalHistory(medicalHistory);
    }
}
