package iitu.edu.kz.medaware.model;

import jakarta.persistence.*;
import java.util.Date;
import java.util.List;
@Entity
@Table(name = "user_surveys")
public class User_Survey {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne
    @JoinColumn(name = "survey_id", nullable = false)
    private Survey survey;

    @Column(name = "response")
    private String response;

    @Column(name = "predicted_diagnosis")
    private String predictedDiagnosis;

    @Column(name = "confidence")
    private Double confidence;

    @Column(name = "submitted_at")
    private Date submittedAt;
}
