package iitu.edu.kz.medaware.service;

import iitu.edu.kz.medaware.model.*;
import iitu.edu.kz.medaware.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class Treatment_planService {
    @Autowired
    private Treatment_planRepository treatmentPlanRepository;

    public List<Treatment_plan> getAllTreatmentPlans() {
        return treatmentPlanRepository.findAll();
    }

    public List<Treatment_plan> getTreatmentPlansByUserId(Integer userId) {
        return treatmentPlanRepository.findByUserIdOrderByStartDateDesc(userId);
    }

    public Treatment_plan saveTreatmentPlan(Treatment_plan treatmentPlan) {
        return treatmentPlanRepository.save(treatmentPlan);
    }
}
