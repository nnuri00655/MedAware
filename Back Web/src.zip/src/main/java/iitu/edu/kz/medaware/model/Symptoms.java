package iitu.edu.kz.medaware.model;

import jakarta.persistence.*;
import java.util.Date;
import java.util.List;
@Entity
@Table(name = "symptoms")
public class Symptoms {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(name = "symptom_description", nullable = false)
    private String symptomDescription;

    @Column(name = "severity_level", nullable = false)
    private Integer severityLevel;

    @Column(name = "reported_at")
    private Date reportedAt;
}
