package iitu.edu.kz.medaware.service;

import iitu.edu.kz.medaware.model.*;
import iitu.edu.kz.medaware.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class SymptomsService {
    @Autowired
    private SymptomsRepository symptomsRepository;

    public List<Symptoms> getAllSymptoms() {
        return symptomsRepository.findAll();
    }

    public Symptoms saveSymptom(Symptoms symptom) {
        return symptomsRepository.save(symptom);
    }
}
