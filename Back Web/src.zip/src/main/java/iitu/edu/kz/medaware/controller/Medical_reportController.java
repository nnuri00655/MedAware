package iitu.edu.kz.medaware.controller;

import iitu.edu.kz.medaware.model.*;
import iitu.edu.kz.medaware.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/medical-reports")
public class Medical_reportController {

    @Autowired
    private Medical_reportService medicalReportService;

    @GetMapping
    public List<Medical_report> getAllMedicalReports() {
        return medicalReportService.getAllMedicalReports();
    }

    @PostMapping
    public Medical_report saveMedicalReport(@RequestBody Medical_report medicalReport) {
        return medicalReportService.saveMedicalReport(medicalReport);
    }
}
