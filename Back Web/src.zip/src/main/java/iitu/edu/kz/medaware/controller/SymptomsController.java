package iitu.edu.kz.medaware.controller;

import iitu.edu.kz.medaware.model.*;
import iitu.edu.kz.medaware.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/symptoms")
public class SymptomsController {

    @Autowired
    private SymptomsService symptomsService;

    @GetMapping
    public List<Symptoms> getAllSymptoms() {
        return symptomsService.getAllSymptoms();
    }

    @PostMapping
    public Symptoms saveSymptom(@RequestBody Symptoms symptom) {
        return symptomsService.saveSymptom(symptom);
    }
}
