package iitu.edu.kz.medaware.repository;

import iitu.edu.kz.medaware.model.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface User_SurveyRepository extends JpaRepository<User_Survey, Integer> {
}

