package iitu.edu.kz.medaware.service;

import iitu.edu.kz.medaware.model.*;
import iitu.edu.kz.medaware.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class Medical_reportService {
    @Autowired
    private Medical_reportRepository medicalReportRepository;

    public List<Medical_report> getAllMedicalReports() {
        return medicalReportRepository.findAll();
    }

    public Medical_report saveMedicalReport(Medical_report medicalReport) {
        return medicalReportRepository.save(medicalReport);
    }
}
