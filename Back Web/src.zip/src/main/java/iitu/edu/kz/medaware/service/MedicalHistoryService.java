package iitu.edu.kz.medaware.service;

import iitu.edu.kz.medaware.model.*;

import iitu.edu.kz.medaware.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class MedicalHistoryService {
    @Autowired
    private MedicalHistoryRepository medicalHistoryRepository;

    public List<Medical_history> getAllMedicalHistories() {
        return medicalHistoryRepository.findAll();
    }

    public Medical_history saveMedicalHistory(Medical_history medicalHistory) {
        return medicalHistoryRepository.save(medicalHistory);
    }
}
