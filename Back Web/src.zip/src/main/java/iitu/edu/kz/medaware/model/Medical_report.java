package iitu.edu.kz.medaware.model;
import jakarta.persistence.*;
import java.util.Date;
import java.util.List;
@Entity
@Table(name = "medical_reports")
public class Medical_report {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(name = "report_text", nullable = false)
    private String reportText;

    @Column(name = "generated_at")
    private Date generatedAt;
}
