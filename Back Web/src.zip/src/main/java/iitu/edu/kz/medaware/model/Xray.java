package iitu.edu.kz.medaware.model;

import jakarta.persistence.*;
import java.util.Date;
import java.util.List;
@Entity
@Table(name = "xray_images")
public class Xray {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(name = "image_url", nullable = false)
    private String imageUrl;

    @Column(name = "analysis_result", nullable = false)
    private String analysisResult;

    @Column(name = "probability")
    private Double probability;

    @Column(name = "uploaded_at")
    private Date uploadedAt;
}
