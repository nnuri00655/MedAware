CREATE TABLE IF NOT EXISTS users
(
    id                 INTEGER PRIMARY KEY,
    name               VARCHAR(100) NOT NULL,
    email              VARCHAR(254) NOT NULL UNIQUE,
    password           VARCHAR(255) NOT NULL,
    birth_date         DATE,
    gender             VARCHAR(10),
    phone_number       VARCHAR(15),
    registration_date  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE SEQUENCE users_id_seq START WITH 1 INCREMENT BY 1;

CREATE DATABASE test;
